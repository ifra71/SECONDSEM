﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{

    // chalnege 1



//class clockType
//    {
//        private int hr;
//        private int min;
//        private int sec;

//        public void setTime(int hours, int minutes, int seconds)
//        {
//            if (hours >= 0 && hours < 24 && minutes >= 0 && minutes < 60 && seconds >= 0 && seconds < 60)
//            {
//                hr = hours;
//                min = minutes;
//                sec = seconds;
//            }
//            else
//            {
//                Console.WriteLine("Invalid time value.");
//            }
//        }

//        public void elapsedTimeInSeconds()
//        {
//            int elapsedSeconds = (hr * 60 * 60) + (min * 60) + sec;
//            Console.WriteLine("Elapsed Time (seconds): " + elapsedSeconds);
//        }

//        public void remainingTimeInSeconds()
//        {
//            int remainingSeconds = ((24 - hr) * 60 * 60) + ((60 - min) * 60) + (60 - sec);
//            Console.WriteLine("Remaining Time (seconds): " + remainingSeconds);
//        }

//        public void timeDifferenceInSeconds(clockType otherClock)
//        {
//            int thisTimeInSeconds = (hr * 60 * 60) + (min * 60) + sec;
//            int otherTimeInSeconds = (otherClock.hr * 60 * 60) + (otherClock.min * 60) + otherClock.sec;
//            int difference = Math.Abs(thisTimeInSeconds - otherTimeInSeconds);
//            Console.WriteLine("Time Difference (seconds): " + difference);
//        }

//        public void displayTime()
//        {
//            string timeString = String.Format("{0:D2}:{1:D2}:{2:D2}", hr, min, sec);
//            Console.WriteLine("Current Time: " + timeString);
//        }
//    }
   // lab

   
  
}

