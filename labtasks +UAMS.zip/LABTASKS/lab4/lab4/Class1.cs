﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class student
    {
        //  prob state self assess library

        //public string name;
        //    public int age;
        //    public List<Book> books;

        //    public Student(string name, int age)
        //    {
        //        this.name = name;
        //        this.age = age;
        //        books = new List<Book>();
        //    }

        //    public void AddBook(Book book)
        //    {
        //        books.Add(book);
        //        Console.WriteLine("Book added to student's collection.");
        //    }

        //    public void ReadBook(int bookIndex, int chapterNumber)
        //    {
        //        if (bookIndex >= 0 && bookIndex < books.Count)
        //        {
        //            Book book = books[bookIndex];
        //            string chapter = book.GetChapter(chapterNumber);
        //            Console.WriteLine("Reading Book: " + bookIndex + ", Chapter: " + chapterNumber);
        //            Console.WriteLine("Chapter Content: " + chapter);
        //            book.SetBookmark(chapterNumber + 1);
        //        }
        //        else
        //        {
        //            Console.WriteLine("Invalid book index.");
        //        }
        //    }

        //    public void DisplayBookmarks()
        //    {
        //        Console.WriteLine("Bookmarks:");
        //        for (int i = 0; i < books.Count; i++)
        //        {
        //            Book book = books[i];
        //            int bookmark = book.GetBookmark();
        //            Console.WriteLine("Book: " + i + ", Bookmark: " + bookmark);
        //        }
        //    }




        //------------------------------------------//


    }
}

