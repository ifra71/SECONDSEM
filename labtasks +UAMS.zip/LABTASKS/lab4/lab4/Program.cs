﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            //  prob state self assess library

            //    Book book1 = new Book("Author 1", 200, new List<string> { "Chapter 1", "Chapter 2", "Chapter 3" }, 0, 10);
            //    Book book2 = new Book("Author 2", 150, new List<string> { "Chapter 1", "Chapter 2", "Chapter 3", "Chapter 4" }, 0, 15);

            //    Student student = new Student("", 20);
            //    student.AddBook(book1);
            //    student.AddBook(book2);

            //    student.ReadBook(0, 2);
            //    student.ReadBook(1, 1);

            //    student.DisplayBookmarks();

            //    book1.SetBookPrice(20);
            //}
        }
    }



