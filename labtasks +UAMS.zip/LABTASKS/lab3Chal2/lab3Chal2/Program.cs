﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3Chal2
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                DepartmentalStore store = new DepartmentalStore();

                store.AddProduct("Product 1", 10.99, 20, 0.05, 10);
                store.AddProduct("Product 2", 5.99, 8, 0.03, 15);
                store.AddProduct("Product 3", 25.99, 5, 0.07, 5);

                store.ViewAllProducts();
                store.FindProductWithHighestUnitPrice();
                store.ViewSalesTaxOfAllProducts();
                store.ViewProductsToBeOrdered();
            }
        }
    }
}
