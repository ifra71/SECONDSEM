﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            // challenge 1 //
            //        int choice;

            //        do
            //        {
            //            Console.WriteLine("Menu:");
            //            Console.WriteLine("1. Add Products");
            //            Console.WriteLine("2. Show Products");
            //            Console.WriteLine("3. Total Store Worth");
            //            Console.WriteLine("4. Exit");
            //            Console.Write("Enter your choice: ");
            //            choice = int.Parse(Console.ReadLine());

            //            if (choice == 1)
            //            {
            //                AddProduct();
            //            }
            //            else if (choice == 2)
            //            {
            //                ShowProducts();
            //            }
            //            else if (choice == 3)
            //            {
            //                CalculateTotalStoreWorth();
            //            }
            //            else if (choice == 4)
            //            {
            //                Console.WriteLine("Exiting program...");
            //            }
            //            else
            //            {
            //                Console.WriteLine("Invalid choice. Please try again.");
            //            }

            //            Console.WriteLine();
            //        } while (choice != 4);
            //    }

            //    static void AddProduct()
            //    {
            //        Product product = new Product();

            //        Console.WriteLine("Add Product:");
            //        Console.Write("Enter ID: ");
            //        product.ID = int.Parse(Console.ReadLine());

            //        Console.Write("Enter Name: ");
            //        product.Name = Console.ReadLine();

            //        Console.Write("Enter Price: ");
            //        product.Price = decimal.Parse(Console.ReadLine());

            //        Console.Write("Enter Category: ");
            //        product.Category = Console.ReadLine();

            //        Console.Write("Enter Brand Name: ");
            //        product.BrandName = Console.ReadLine();

            //        Console.Write("Enter Country: ");
            //        product.Country = Console.ReadLine();

            //        products[productCount] = product;
            //        productCount++;

            //        Console.WriteLine("Product added successfully.");
            //    }

            //    static void ShowProducts()
            //    {
            //        if (productCount == 0)
            //        {
            //            Console.WriteLine("No products added yet.");
            //        }
            //        else
            //        {
            //            Console.WriteLine("List of Products:");
            //            for (int i = 0; i < productCount; i++)
            //            {
            //                Product product = products[i];
            //                Console.WriteLine($"ID: {product.ID}");
            //                Console.WriteLine($"Name: {product.Name}");
            //                Console.WriteLine($"Price: {product.Price}");
            //                Console.WriteLine($"Category: {product.Category}");
            //                Console.WriteLine($"Brand Name: {product.BrandName}");
            //                Console.WriteLine($"Country: {product.Country}");
            //                Console.WriteLine();
            //            }
            //        }
            //    }

            //    static void CalculateTotalStoreWorth()
            //    {
            //        decimal totalWorth = 0;
            //        for (int i = 0; i < productCount; i++)
            //        {
            //            Product product = products[i];
            //            totalWorth += product.Price;
            //        }
            //        Console.WriteLine($"Total Store Worth: {totalWorth}");
            //    }
            //}
            // challenge 2 // 



            //    Credentials[] credentials = LoadCredentialsFromFile();

            //    int choice;

            //    do
            //    {
            //        Console.WriteLine("Menu:");
            //        Console.WriteLine("1. Sign Up");
            //        Console.WriteLine("2. Sign In");
            //        Console.WriteLine("3. Exit");
            //        Console.Write("Enter your choice: ");
            //        choice = int.Parse(Console.ReadLine());

            //        if (choice == 1)
            //        {
            //            SignUp(credentials);
            //        }
            //        else if (choice == 2)
            //        {
            //            SignIn(credentials);
            //        }
            //        else if (choice == 3)
            //        {
            //            Console.WriteLine("Exiting program...");
            //        }
            //        else
            //        {
            //            Console.WriteLine("Invalid choice. Please try again.");
            //        }

            //        Console.WriteLine();
            //    } while (choice != 3);
            //}

        }
    }


}