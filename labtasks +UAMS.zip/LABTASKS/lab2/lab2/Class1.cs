﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    //challenge 1//
    //class Product
    //{
    //    public int ID;
    //    public string Name;
    //    public decimal Price;
    //    public string Category;
    //    public string BrandName;
    //    public string Country;
    //}
    // challenge 2 
    class 
}
