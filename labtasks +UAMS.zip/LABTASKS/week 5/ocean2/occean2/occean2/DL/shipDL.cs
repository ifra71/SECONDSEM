﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using occean2.BL;
using occean2.UI;

namespace occean2.DL
{
   
    class shipDL
    {
        public static List<ship> ship1 = new List<ship>();
        public static void findship(List<ship> ship1)
        {
            for (int i = 0; i < ship1.Count; i++)
            {
                if (shipUI.print2() == ship1[i].ship_number)
                {
                    ship1[i].longitude.changevalues(angleUI.printlongdeg(), angleUI.printlongmin(), angleUI.printlongdir());
                    ship1[i].latitude.changevalues(angleUI.printlatdeg(), angleUI.printlatmin(), angleUI.printlatdir());
                }
            }
        }
        public static void load()
        {
            string path = "F:\\semester 2\\oop\\week 5\\ocean2\\occean2\\ocean.txt";
            StreamReader file = new StreamReader(path);
            string record;

            while ((record = file.ReadLine()) != null)
            {
                if (record == "") break;

                string[] splittedrec = record.Split(',');
                int no = int.Parse(splittedrec[0]);
                int deg = int.Parse(splittedrec[1]);
                float min = float.Parse(splittedrec[2]);  
                char Dir = char.Parse(splittedrec[3]);
                int deg1 = int.Parse(splittedrec[4]);
                float min1 = float.Parse(splittedrec[5]);
                char Dir1 = char.Parse(splittedrec[6]);
                angle lon = new angle(deg, min, Dir);
                angle lat = new angle(deg1, min1, Dir1);
                ship a = new ship(no, lon, lat);
                ship1.Add(a);

            }
            file.Close();
        }
        public static void store()
        {

            string path = "F:\\semester 2\\oop\\week 5\\ocean2\\occean2\\ocean.txt";
            StreamWriter file = new StreamWriter(path,true);
            for (int i = 0; i < ship1.Count; i++) 
            {
                file.WriteLine(ship1[i].ship_number + "," + ship1[i].longitude.degree + "," + ship1[i].longitude.minutes + "," + ship1[i].longitude.direction + "," + ship1[i].latitude.degree + "," + ship1[i].latitude.minutes + "," + ship1[i].latitude.direction);
                Console.WriteLine(ship1[i].ship_number + "," + ship1[i].longitude.degree + "," + ship1[i].longitude.minutes + "," + ship1[i].longitude.direction + "," + ship1[i].latitude.degree + "," + ship1[i].latitude.minutes + "," + ship1[i].latitude.direction);
            }
            file.Close();
        }
    }
}
