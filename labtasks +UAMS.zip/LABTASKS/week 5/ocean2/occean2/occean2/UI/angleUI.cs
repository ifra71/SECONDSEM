﻿using System;
using System.Collections.Generic;
using System.Text;

namespace occean2.UI
{
    class angleUI
    {
        public static int printlongdeg()
        {
            Console.WriteLine("enter the degree of longitude");
           return int.Parse(Console.ReadLine());
        }
        public static int printlatdeg()
        {
            Console.WriteLine("enter the degree of latitude");
            return int.Parse(Console.ReadLine());
        }
        public static float printlongmin()
        {
            Console.WriteLine("enter the minutes of longitude");
            return float.Parse(Console.ReadLine());
        }
        public static float printlatmin()
        {
            Console.WriteLine("enter the minutes of latitude");
            return float.Parse(Console.ReadLine());
        }
        public static char printlongdir()
        {
            Console.WriteLine("enter the direction of longitude");
            return char.Parse(Console.ReadLine());
        }
        public static char printlatdir()
        {
            Console.WriteLine("enter the direction of latitude");
            return char.Parse(Console.ReadLine());
        }
        public static int printshipnumber()
        {
            Console.WriteLine("enter the serial number of ship");
            return int.Parse(Console.ReadLine());
        }
      
    }
}
