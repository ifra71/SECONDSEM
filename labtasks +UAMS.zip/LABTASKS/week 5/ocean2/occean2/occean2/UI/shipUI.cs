﻿using System;
using System.Collections.Generic;
using System.Text;
using occean2.BL;

namespace occean2.UI
{
    class shipUI
    {

        public static void viewshipnumber(ship p)
        {
            Console.WriteLine("ship serial number is {0}", p.ship_number);
        }
        public static void veiwposition(ship p)
        {
            Console.WriteLine("ship is at {0} latitude and {1} longitude", p.latitude.printdirection(), p.longitude.printdirection());
        }
        public static int input()
        {

            Console.WriteLine("enter the serial number of ship which u wanna see the location");
            return int.Parse(Console.ReadLine());
        }
        public static void viewshipposition(List<ship> ship1)
        {
            for (int i = 0; i < ship1.Count; i++)
            {
                if (input() == ship1[i].ship_number)
                {
                    veiwposition(ship1[i]);
                }
            }
        }
        public static void viewshipserialnumber(List<ship> ship1)
        {
            for (int i = 0; i < ship1.Count; i++)
            {
                Console.WriteLine("{0}", ship1[i].ship_number);
            }
        }
        public static int print2()
        {
            Console.WriteLine("enter the serial number of ship which u wanna change the location");
            return int.Parse(Console.ReadLine());
        }
       
            public static int mainmenu()
            {
            int option;
            Console.WriteLine("1.Add ship");
            Console.WriteLine("2.View Ship Postion");
            Console.WriteLine("3.View Ship Serial Number");
            Console.WriteLine("4.Change Ship Position ");
            Console.WriteLine("Enter your postion");
            option = int.Parse(Console.ReadLine());
            return option;
        }
    }
}
