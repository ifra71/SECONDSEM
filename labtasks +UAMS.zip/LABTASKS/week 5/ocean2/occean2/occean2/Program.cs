﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using occean2.BL;
using occean2.UI;
using occean2.DL;
namespace occean2
{
    class Program
    {
        static void Main(string[] args)
        {          
            bool running = true;
            shipDL.load();
            while (running)
            {
                int opt = shipUI.mainmenu();
                if (opt == 1)
                {
                    angle longitude1 = new angle(angleUI.printlongdeg(), angleUI.printlongmin(), angleUI.printlongdir());
                    angle latitude1 = new angle(angleUI.printlatdeg(), angleUI.printlatmin(), angleUI.printlatdir());
                    ship a = new ship(angleUI.printshipnumber(), longitude1, latitude1);
                    shipDL.ship1.Add(a);
                }
                else if (opt == 2)
                {
                    shipUI.viewshipposition(shipDL.ship1);
                }
                else if (opt == 3)
                {
                    shipUI.viewshipserialnumber(shipDL.ship1);
                }
                else if (opt == 4)
                {
                    shipDL.findship(shipDL.ship1);
                         
                }
                else if(opt == 5)
                {
                    running = false;
                }
            }
            shipDL.store();
        }
    }
}
