﻿using System;
using System.Collections.Generic;
using System.Text;

namespace occean2.BL
{
    class angle
    {
        public int degree;
        public float minutes;
        public char direction;
        public angle(int degree, float minutes, char direction)
        {
            this.degree = degree;
            this.minutes = minutes;
            this.direction = direction;
        }
        public void changevalues(int newdegree, float newminutes, char newdirection)
        {
            degree = newdegree;
            minutes = newminutes;
            direction = newdirection;
        }
        public string printdirection()
        {
            string a = (degree + "\u00b0" + minutes + "\'" + direction);
            return a;
        }
    
    }
}
