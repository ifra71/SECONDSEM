﻿using System;
using System.Collections.Generic;
using System.Text;

namespace occean2.BL
{
    class ship
    {
        public int ship_number;
        public angle longitude;
        public angle latitude;
        public ship(int ship_number, angle longitude, angle latitude)
        {
            this.ship_number = ship_number;
            this.latitude = latitude;
            this.longitude = longitude;
        }

    }
}
