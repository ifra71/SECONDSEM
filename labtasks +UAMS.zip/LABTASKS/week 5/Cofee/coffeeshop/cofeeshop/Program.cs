﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using coffeeshap.BL;
using coffeeshap.UI;
using coffeeshap.DL;
namespace coffeeshap
{
    class Program
    {
     public static coffeeshop shop=new coffeeshop("Golria Jeans");
       
        static void Main(string[] args)
        {
            
            caffeeshopDL.load();
            orderDL.load();

            while (true)
            {
                int opt = codeeshopUI.mainMenu();
                
               
                if (opt == 1) 
                {
                    MenuItem p = new MenuItem(MenuItemUI.addamenuname(), MenuItemUI.addamenutype(), MenuItemUI.addamenuprice());
                    shop.addthingsintolist(p);
                }
                else if (opt == 2)
                {

                    codeeshopUI.print( shop.cheapestitem());
                }
                else if (opt == 3)
                {
                    codeeshopUI.print2(shop.drinksonly());

                }
                else if (opt == 4)
                {
                    codeeshopUI.print2(shop.foodonly());
                }
                else if (opt == 5)
                {
                    bool f = shop.addorder(codeeshopUI.takeorder());
                    codeeshopUI.print3(f);
                }
                else if (opt == 6)
                {
                    codeeshopUI.print4(shop.fulfilorder());
                }
                else if (opt == 7)
                {
                    codeeshopUI.print5(shop.getorder());
                }
                else if (opt == 8)
                {
                    codeeshopUI.print6(shop.dueamount());
                }
                else
                {
                    r=false;
                }
            }

            codeeshopUI.print7();
            orderDL.store(shop.getorder());
            caffeeshopDL.store(shop.getlist());
        } 
    }
}
