﻿using System;
using System.Collections.Generic;
using System.Text;

namespace coffeeshap.BL
{
    class MenuItem
    {
        private string name;
        private string type;
        private uint price;

        public MenuItem(string name, string type, uint price)
        {
            this.name = name;
            this.type = type;
            this.price = price;
        }
        public void setname(string name) => this.name = name;
        public string getname() => name;

        public void settype(string type) => this.type = type;
        public string gettype() => type;
        public void setprice(uint price) => this.price = price;
        public uint getprice() => price;
    }
}
