﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using coffeeshap.BL;

namespace coffeeshap.BL
{
    class coffeeshop
    {
        private string name;
        private List<MenuItem> menuitem = new List<MenuItem>();
        private List<string> orders=new List<string>();

        public void setorder(List<string> orders) => this.orders = orders;
        public List<string> getorder() => orders;
        public void setname(string name) => this.name = name;
        public string getname() => name;
        public List<MenuItem> getlist() => menuitem;
        public void setlist(List<MenuItem> menuitem) => this.menuitem = menuitem;
        public coffeeshop(string name)
        {
            this.name = name;
        }
        public void addthingsintolist(MenuItem name)
        {
            menuitem.Add(name);
        }
        public int countreturn() => menuitem.Count;
            
        
        public string findnameinmenulist(string n)
        {
            foreach (MenuItem h in menuitem)
            {
                if (h.getname() == n)
                {
                    return n;
                }
            }
            return null;
        }
        public MenuItem findmenuinmenulist(string n)
        {
            foreach (MenuItem h in menuitem)
            {
                if (h.getname() == n)
                {
                    return h;
                }
            }
            return null;
        }
        public bool addorder(string n)
        {
            if (findnameinmenulist(n) != null)
            {
                orders.Add(n);
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool fulfilorder()
        {
            if (orders.Count != 0)
            {
                orders.RemoveAt(orders.Count - 1);
                return true;
            }
            else
            {
                return false;  
            }
        }
        public uint dueamount()
        {
            uint a = 0;
            for (int x = 0; x < orders.Count; x++)
            {
                for (int i = 0; i < menuitem.Count; i++)
                {
                    if (orders[x] == menuitem[i].getname())
                    {
                        a += menuitem[i].getprice();
                    }
                }

            }
            return a;
        }
        public string cheapestitem()
        {
           
                if(menuitem.Count==0)
                {
                    return "N/A";
                }
                else
                {
                    MenuItem cheap;
                    cheap = menuitem[0];
                    foreach(MenuItem check in menuitem)
                    {
                        if(check.getprice()<cheap.getprice())
                        {
                            cheap = check;
                        }
                    }
                    return cheap.getname();
                }
            
        }
        public List<string> drinksonly()
        {
            List<string> lol= new List<string>();
            for(int i=0;i<menuitem.Count;i++)
            {
                if (menuitem[i].gettype()=="drink")
                {
                    lol.Add(menuitem[i].getname());
                }
            }
            return lol;
        }
        public List<string> foodonly()
        {
            List<string> lol = new List<string>();
            for (int i = 0; i < menuitem.Count; i++)
            {
                if (menuitem[i].gettype() == "food")
                {
                    lol.Add(menuitem[i].getname());
                }
            }
            return lol;
        }
    }
}
