﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using coffeeshap.BL;
using coffeeshap.UI;

namespace coffeeshap.DL
{
    class orderDL
    {
        public static void load()
        {
            string path = "F:\\semester 2\\oop\\week 5\\pd\\coffeeshap\\order.txt";
            StreamReader file = new StreamReader(path);
            string record;

            while ((record = file.ReadLine()) != null)
            {
                if (record == "") break;
                string n = record;
                Program.shop.addorder(n);
            }
        }
        public static void store(List<string> order)
        {

            string path = "F:\\semester 2\\oop\\week 5\\pd\\coffeeshap\\order.txt";
            StreamWriter file = new StreamWriter(path);
            for (int i = 0; i < order.Count; i++)
            {
                file.WriteLine(order[i]);
            }
            file.Flush();
            file.Close();
        }
    }
}
