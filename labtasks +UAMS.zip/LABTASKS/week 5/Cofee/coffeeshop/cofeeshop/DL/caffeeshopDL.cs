﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using coffeeshap.BL;
using coffeeshap.UI;
namespace coffeeshap.DL
{
    class caffeeshopDL
    {
        public static void load()
        {
            string path = "F:\\semester 2\\oop\\week 5\\pd\\coffeeshap\\shop.txt";
            StreamReader file = new StreamReader(path);
            string record;

            while ((record = file.ReadLine()) != null)
            {
                if (record == "") break;

                string[] splittedrec = record.Split(',');
                MenuItem m = new MenuItem(splittedrec[0], splittedrec[1],uint.Parse(splittedrec[2]));
                Program.shop.addthingsintolist(m);
            }
            file.Close();
        }
        public static void store(List<MenuItem> menuitem)
        {
          
            string path = "F:\\semester 2\\oop\\week 5\\pd\\coffeeshap\\shop.txt";
            StreamWriter file = new StreamWriter(path);
            for (int i = 0; i <menuitem.Count; i++)
            {
                file.WriteLine(menuitem[i].getname() + "," + menuitem[i].gettype() + "," + menuitem[i].getprice());
            }
            file.Flush();
            file.Close();
        }
    }
}
