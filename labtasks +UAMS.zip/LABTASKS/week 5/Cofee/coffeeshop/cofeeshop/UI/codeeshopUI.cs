﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using coffeeshap.BL;
using coffeeshap.UI;
namespace coffeeshap.UI
{
    class codeeshopUI
    {
        public static int mainMenu()
        {
            Console.WriteLine("Welcome to the Tesha's Coffee Shop");
            Console.WriteLine("1.Add a Menu Item");
            Console.WriteLine("2.View the Cheapest item in the menu");
            Console.WriteLine("3.View the Drink's Menu");
            Console.WriteLine("4.View the Food's Menu");
            Console.WriteLine("5.Add order");
            Console.WriteLine("6.Fulfil the Order");
            Console.WriteLine("7.View the Order's List");
            Console.WriteLine("8.Total Payable Amount");
            Console.WriteLine("9.Exit");
            Console.WriteLine("enter ur option");
            int a = int.Parse(Console.ReadLine());
            return a;
        }
        public static void print(string i)
        {
            Console.WriteLine("{0} is cheapest item in record", i);
        }
        public static void print2(List<string> l)
        {
            for(int x=0;x<l.Count;x++)
            {
                Console.WriteLine(l[x]);
            }
        }
        public static string takeorder()
        {
            Console.WriteLine("enter the order you wanna place");
            return Console.ReadLine();
        }
        public static string print3 (bool a)
        {
            if(a==true)
            {
                return "the order has been taken ";
            }
            else
            {
                return "enter a valid order";
            }
        }
        public static string print4(bool a)
        {
          
            if (a == true)
            {
                return "the ite  have been placed";
            }
            else
            {
                return "All orders has been returned";
            }
        }
        public static void print5(List<string> a)
        {
            for (int x = 0; x < a.Count; x++)
            {
                Console.WriteLine(a[x]);
            }
        }
        public static void print6(uint a)
        {
            Console.WriteLine("{0} is total payable amount", a);
        }
        public static void print7()
        {
            Console.WriteLine("that's the end of road");
        }
    }
}
