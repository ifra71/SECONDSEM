﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using coffeeshap.BL;
using coffeeshap.UI;

namespace coffeeshap.UI
{
    class MenuItemUI
    {
       public static string addamenuname()
        {
            string a;
            Console.WriteLine("enter the name of item");
            a = Console.ReadLine();
            return a;
        }
        public static string addamenutype()
        {
            string a;
            Console.WriteLine("enter the type of item");
            a = Console.ReadLine();
            return a;
        }
        public static uint addamenuprice()
        {
            uint a;
            Console.WriteLine("enter the price of item");
            a = uint.Parse(Console.ReadLine());
            return a;
        }

    }
}
